import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MarvelSeriesDetailPageRoutingModule } from './marvel-series-detail-routing.module';

import { MarvelSeriesDetailPage } from './marvel-series-detail.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MarvelSeriesDetailPageRoutingModule
  ],
  declarations: [MarvelSeriesDetailPage]
})
export class MarvelSeriesDetailPageModule {}
