import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { SeriesService } from '../../services/series.service' ;
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NavController, NavParams } from '@ionic/angular';
import { Series } from 'src/app/models/series';
@Component({
  selector: 'app-marvel-series-detail',
  templateUrl: './marvel-series-detail.page.html',
  styleUrls: ['./marvel-series-detail.page.scss'],
  providers: [NavParams]
})
export class MarvelSeriesDetailPage implements OnInit {
  
  id : number = 0;
  series: Series;
  obj:any;
  constructor(public navCtrl: NavController, public navParams: NavParams,
     public seriesService: SeriesService, private location: Location, private route: ActivatedRoute) { 

      let id = this.route.snapshot.paramMap.get('id'); 
      if(id) this.id = parseInt(id);
      this.seriesService.getDetail(this.id)
      .then(data => {
        this.series = data;
      });
       
        
        

        
     }

  ngOnInit() {
  }
  goBack(): void {
    this.location.back();
  
  }


}
