import { Component, OnInit, ViewChild } from '@angular/core';
import { SeriesService } from '../../services/series.service' ;
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { IonSearchbar, NavController } from '@ionic/angular';
@Component({
  selector: 'app-marvel-series',
  templateUrl: './marvel-series.page.html',
  styleUrls: ['./marvel-series.page.scss'],
})
export class MarvelSeriesPage implements OnInit  {

  @ViewChild('search',{ static:false}) search: IonSearchbar;
  public list: Array<Object> = [];
  private searchedItem:any;

  constructor(public navCtrl: NavController){
    this.list =[
    {
			"id":1,
			"name": "Iron Man",
			"wiki": "Iron Man (film)",
			"series": "Iron Man",
			"phase": 1,
			"released": "2008-05-02",
			"poster": "iron-man-movie-poster-marvel-cinematic-universe-1038878.jpg",
			"endCreditsLink": ["The Avengers"]
		},
		{
			"id":2,
			"name": "The Incredible Hulk",
			"wiki": "The Incredible Hulk (film)",
		
			"series": "Hulk",
			"phase": 1,
			"released": "2008-06-13",
			"poster": "the-incredible-hulk-movie-poster-marvel-cinematic-universe-1038886.jpg",
			"endCreditsLink": ["The Avengers"]
		},
		{
			"id":3,
			"name": "Iron Man 2",
			"wiki": "Iron Man 2",
			"series": "Iron Man",
			"phase": 1,
			"released": "2010-05-07",
			"poster": "iron-man-2-movie-poster-marvel-cinematic-universe-1038887.jpg",
			"endCreditsLink": ["Thor"]
		},
		{
			"id":4,
			"name": "Thor",
			"wiki": "Thor (film)",
			"series": "Thor",
			"phase": 1,
			"released": "2011-05-06",
			"poster": "thor-movie-poster-marvel-cinematic-universe-1038890.jpg",
			"endCreditsLink": ["Captain America: The First Avenger", "TheAvengers"]
		},
		{
			"id":5,
			"name": "Captain America: The First Avenger",
			"wiki": "Captain America: The First Avenger",
			"series": "Captain America",
			"phase": 1,
			"released": "2011-07-22",
			"poster": "captain-america-the-first-avenger-movie-poster-marvel-cinematic--1038891.jpg",
			"endCreditsLink": ["The Avengers"]
		},
		{
			"id":6,
			"name": "The Avengers",
			"wiki": "The Avengers (film)",
			"series": "Avengers",
			"phase": 1,
			"released": "2012-05-04",
			"poster": "the-avengers-movie-poster-marvel-cinematic-universe-1038892.jpg",
			"endCreditsLink": ["Guardians of the Galaxy"]
		},
		{
			"id":7,
			"name": "Iron Man 3",
			"wiki": "Iron Man 3",
			"series": "Iron Man",
			"phase": 2,
			"released": "2013-05-03",
			"poster": "iron-man-3-movie-poster-marvel-cinematic-universe-1038894.jpg",
			"endCreditsLink": []
		},
		{
			"id":8,
			"name": "Captain America: The Winter Soldier",
			"wiki": "Captain America: The Winter Soldier",
			"series": "Captain America",
			"phase": 2,
			"released": "2014-04-04",
			"poster": "captain-america-the-winter-soldier-movie-poster-marvel-cinematic-1038896.jpg",
			"endCreditsLink": ["Avengers: Age of Ultron", "Captain America:Civil War"]
		},
		{
			"id":9,
			"name": "Guardians of the Galaxy",
			"wiki": "Guardians of the Galaxy (film)",
			"series": "Guardians of the Galaxy",
			"phase": 2,
			"released": "2014-08-01",
			"poster": "guardians-of-the-galaxy-movie-poster-marvel-cinematic-universe-1038897.jpg",
			"endCreditsLink": []
		},
		{
			"id":10,
			"name": "Avengers: Age of Ultron",
			"wiki": "Avengers: Age of Ultron",
			"series": "Avengers",
			"phase": 2,
			"released": "2015-05-01",
			"poster": "avengers-2-movie-poster-marvel-cinematic-universe-1038898.jpg",
			"endCreditsLink": ["Avengers: Infinity War"]
		},
		{
			"id":11,
			"name": "Ant-Man",
			"wiki": "Ant-Man (film)",
			"series": "Ant-Man",
			"phase": 2,
			"released": "2015-07-17",
			"poster": "ant-man-movie-poster-marvel-cinematic-universe-1038903.jpg",
			"endCreditsLink": ["Captain America: Civil War", "Ant-Man and theWasp"]
		},
		{
			"id":12,
			"name": "Doctor Strange",
			"wiki": "Doctor Strange (film)",
			"series": "Doctor Strange",
			"phase": 3,
			"released": "2016-11-04",
			"poster": "doctor-strange-movie-poster-marvel-cinematic-universe-1038908.jpg",
			"endCreditsLink": ["Thor: Ragnarok"]
		},
		{
			"id":13,
			"name": "Guardians of the Galaxy Vol. 2",
			"wiki": "Guardians of the Galaxy Vol. 2",
			"series": "Guardians of the Galaxy",
			"phase": 3,
			"released": "2017-05-05",
			"poster": "guardians-of-the-galaxy-2-movie-poster-marvel-cinematic-universe-1038911.jpg",
			"endCreditsLink": ["Guardians of the Galaxy Vol. 3"]
		},
		{
			"id":14,
			"name": "Spider-Man: Homecoming",
			"wiki": "Spider-Man: Homecoming",
			"series": "Spider-Man",
			"phase": 3,
			"released": "2017-07-07",
			"poster": "spider-man-homecoming-movie-poster-marvel-cinematic-universe-1038913.jpg",
			"endCreditsLink": []
		},
		{
			"id":15,
			"name": "Thor: Ragnarok",
			"wiki": "Thor: Ragnarok",
			"series": "Thor",
			"phase": 3,
			"released": "2017-11-03",
			"poster": "thor-3-movie-poster-marvel-cinematic-universe-1038915.png",
			"endCreditsLink": ["Avengers: Infinity War"]
		},
		{
			"id":16,
			"name": "Avengers: Infinity War",
			"wiki": "Avengers: Infinity War",
			"series": "Avengers",
			"phase": 3,
			"released": "2018-04-27",
			"poster": "infinity-war-poster-new.jpg",
			"endCreditsLink": ["Captain Marvel"]
		},
		{
			"id":17,
			"name": "Ant-Man and the Wasp",
			"wiki": "",
			"series": "Ant-Man",
			"phase": 3,
			"released": "2018",
			"poster": "ant-man-and-the-wasp-movie-poster.jpg",
			"endCreditsLink": ["Avengers: Infinity War: Part 2"]
		},
		{
			"id":18,
			"name": "Captain Marvel",
			"wiki": "",
			"series": "Captain Marvel",
			"phase": 4,
			"released": "2019",
			"poster": "",
			"endCreditsLink": []
		},
		{
			"id":19,
			"name": "Avengers: Infinity War: Part 2",
			"wiki": "",
			"series": "Avengers",
			"phase": 4,
			"released": "2019",
			"poster": "",
			"endCreditsLink": []
		}
    ];
    this.searchedItem = this.list
  }


  ngOnInit() {

  }
  ionViewDidEnter(){
    setTimeout(() => {
      this.search.setFocus();
    });
  }

  _ionChange(event){
    const val = event.target.value;
    // this.searchedItem = this.list;
    if (val&& val.trim() !=''){
      this.searchedItem =this.searchedItem.filter((item:any) =>{
      return(item.name.toLowerCase().indexOf(val.toLowerCase())> -1);
    });
  }
  }
  getDescription(id) {


    this.navCtrl.navigateForward('marvel-series/', id)
    console.log(id);
  }


}


 


//     initializaJSONDATA(){


   
//    }
  

