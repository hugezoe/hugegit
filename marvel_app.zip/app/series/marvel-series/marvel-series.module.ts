import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MarvelSeriesPageRoutingModule } from './marvel-series-routing.module';

import { MarvelSeriesPage } from './marvel-series.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MarvelSeriesPageRoutingModule
  ],
  declarations: [MarvelSeriesPage]
})
export class MarvelSeriesPageModule {}
