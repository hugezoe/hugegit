import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MarvelSeriesPage } from './marvel-series.page';

const routes: Routes = [
  {
    path: '',
    component: MarvelSeriesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MarvelSeriesPageRoutingModule {}
