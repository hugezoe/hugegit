import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MarvelStoryPageRoutingModule } from './marvel-story-routing.module';

import { MarvelStoryPage } from './marvel-story.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MarvelStoryPageRoutingModule
  ],
  declarations: [MarvelStoryPage]
})
export class MarvelStoryPageModule {}
