import { Component, OnInit,ViewChild} from '@angular/core';
import { StoryService } from '../../services/story.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { IonSearchbar, NavController } from '@ionic/angular';

@Component({
  selector: 'app-marvel-story',
  templateUrl: './marvel-story.page.html',
  styleUrls: ['./marvel-story.page.scss'],
})
export class MarvelStoryPage implements OnInit {

  @ViewChild('search',{ static:false}) search: IonSearchbar;
  public list: Array<Object> = [];
  private searchedItem:any;
  

  constructor( public navCtrl: NavController,) { 
    this.list =[
      {
        "id":1,
        "name": "Daredevil (Season 1)",
        "wiki": "Daredevil (Netflix series)",
        "series": "Daredevil",
        "season": 1,
        "released": "2015-04-10"
      },
      {
        "id":2,
        "name": "Jessica Jones (Season 1)",
        "wiki": "Jessica Jones (Netflix series)",
        "series": "Jessica Jones",
        "season": 1,
        "released": "2015-11-20"
      },
      {
        "id":3,
        "name": "Daredevil (Season 2)",
        "wiki": "Daredevil (Netflix series)",
        "series": "Daredevil",
        "season": 2,
        "released": "2016-03-18"
      },
      {
        "id":4,
        "name": "Luke Cage (Season 1)",
        "wiki": "Luke Cage (Netflix series)",
        "series": "Luke Cage",
        "season": 1,
        "released": "2016-09-30"
      },
      {
        "id":5,
        "name": "Iron Fist (Season 1)",
        "wiki": "Iron Fist (Netflix series)",
        "series": "Iron Fist",
        "season": 1,
        "released": "2017-03-17"
      },
      {
        "id":6,
        "name": "The Defenders (Season 1)",
        "wiki": "The Defenders (Netflix series)",
        "series": "The Defenders",
        "season": 1,
        "released": "2017-08-18"
      },
      {
        "id":7,
        "name": "The Punisher (Season 1)",
        "wiki": "The Punisher (Netflix series)",
        "series": "The Punisher",
        "season": 1,
        "released": "2017-11-17"
      },
      {
        "id":8,
        "name": "Jessica Jones (Season 2)",
        "wiki": "Jessica Jones (Netflix series)",
        "series": "Jessica Jones",
        "season": 2,
        "released": "2018-03-08"
      },
      {
        "id":9,
        "name": "Luke Cage (Season 2)",
        "wiki": "Luke Cage (Netflix series)",
        "series": "Luke Cage",
        "season": 2,
        "released": "2018-06-22"
      },
      {
        "id":10,
        "name": "Daredevil (Season 3)",
        "wiki": "Daredevil (Netflix series)",
        "series": "Daredevil",
        "season": 3,
        "released": "2018"
      },
      {
        "id":11,
        "name": "Iron Fist (Season 2)",
        "wiki": "Iron Fist (Netflix series)",
        "series": "Iron Fist",
        "season": 2,
        "released": "2018"
      },
      {
        "id":12,
        "name": "The Punisher (Season 2)",
        "wiki": "The Punisher (Netflix series)",
        "series": "The Punisher",
        "season": 2,
        "released": "2018"
      },
      {
        "id":13,
        "name": "Jessica Jones (Season 3)",
        "wiki": "Jessica Jones (Netflix series)",
        "series": "Jessica Jones",
        "season": 3,
        "released": "2018"
      }
    ];
    this.searchedItem = this.list

  }

  ngOnInit() {
  }
  ionViewDidEnter(){
    setTimeout(() => {
      this.search.setFocus();
    });
  }

  _ionChange(event){
    const val = event.target.value;
    // this.searchedItem = this.list;
    if (val&& val.trim() !=''){
      this.searchedItem =this.searchedItem.filter((item:any) =>{
      return(item.name.toLowerCase().indexOf(val.toLowerCase())> -1);
    });
  }
  }
  getDescription(id) {


    this.navCtrl.navigateForward('marvel-story/', id)
    console.log(id);
  }

}
