import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MarvelStoryPage } from './marvel-story.page';

const routes: Routes = [
  {
    path: '',
    component: MarvelStoryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MarvelStoryPageRoutingModule {}
