import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MarvelStoryDetailPageRoutingModule } from './marvel-story-detail-routing.module';

import { MarvelStoryDetailPage } from './marvel-story-detail.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MarvelStoryDetailPageRoutingModule
  ],
  declarations: [MarvelStoryDetailPage]
})
export class MarvelStoryDetailPageModule {}
