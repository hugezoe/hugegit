import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { StoryService } from '../../services/story.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NavController, NavParams } from '@ionic/angular';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Stories } from '../../models/stories';
import { from } from 'rxjs';
@Component({
  selector: 'app-marvel-story-detail',
  templateUrl: './marvel-story-detail.page.html',
  styleUrls: ['./marvel-story-detail.page.scss'],
  providers: [NavParams]
})
export class MarvelStoryDetailPage implements OnInit {
  id : number = 0;
  story: Stories ;
  obj:any;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public storyServ: StoryService, private location: Location, private route: ActivatedRoute) {
      let id = this.route.snapshot.paramMap.get('id'); 
      if(id) this.id = parseInt(id);
      this.storyServ.getDetail(this.id)
      .then(data => {
        this.story = data;
      });
       
        
        

      
    }

  ngOnInit() {
    
  }
  goBack(): void {
    this.location.back();
  }

}
