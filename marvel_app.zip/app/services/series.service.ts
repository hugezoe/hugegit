import { Injectable } from '@angular/core';
import { Md5 } from 'ts-md5/dist/md5';
import { map } from 'rxjs/operators';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Series } from '../models/series';
@Injectable({
  providedIn: 'root'
})
export class SeriesService {

  data: any;


  constructor(public http: HttpClient) {
   
  }
  load() {
    if (this.data) {
      return Promise.resolve(this.data);
    }
    return new Promise(resolve => {
      this.http.get(`/assets/marvel-master/data/mcu-film.json`)
      .pipe(map ((res: Response) => res))
      .subscribe(data => {
        this.data = data;
        resolve(this.data);
      });
    });}
  
  
    getDetail(index: number): Promise<Series> {
      return this.load()
      .then( data => { return data[index] as Series;
      });
    }

  }

