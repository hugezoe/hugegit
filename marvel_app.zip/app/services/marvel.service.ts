import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Marvels,  } from '../models/marvels';

import { from, Observable, pipe } from 'rxjs';
import { Md5 } from 'ts-md5/dist/md5';
import { map } from 'rxjs/operators';


export enum SearchType {
  all = '',
  stories = 'stories',
  characters = 'characters',
  comics = 'comics',

}
@Injectable({ providedIn: 'root' })
export class MarvelService {
  hero: Marvels[]
  data: any;
  ts = Number(new Date());
  Public_Key = '527e8db1531b8f0562d868b1e26e6dd4';
  Private_Key = '322dca321021529615abcebd8d76ddc85b6e4246';
  Url = `https://gateway.marvel.com:443/v1/public`;
  hash = Md5.hashStr(this.ts + this.Private_Key + this.Public_Key).toString();
  constructor(public http: HttpClient) {
    console.log('Hello HeroService');
  }

  load() {
    if (this.data) {
      return Promise.resolve(this.data);
    }
    return new Promise(resolve => {
      let md5 = new Md5();
      var ts = Number(new Date());
      var Public_Key = '527e8db1531b8f0562d868b1e26e6dd4';
      var Private_Key = '322dca321021529615abcebd8d76ddc85b6e4246';
      var Url = `https://gateway.marvel.com:443/v1/public`;
      var hash = Md5.hashStr(ts + Private_Key + Public_Key).toString();
      this.http.get(`https://gateway.marvel.com:443/v1/public/characters?ts=${ts}&apikey=${Public_Key}&hash=${hash}`)
        .pipe(map((res: Response) => res))
        .subscribe(data => {
          this.data = data;
          resolve(this.data);
        });
    });
  }
  // getDescription(id) {
  //   return new Promise(resolve => {
  //     let md5 = new Md5();
  //     var ts = Number(new Date());
  //     var Public_Key = '527e8db1531b8f0562d868b1e26e6dd4';
  //     var Private_Key = '322dca321021529615abcebd8d76ddc85b6e4246';
  //     // var Url = `https://gateway.marvel.com:443/v1/public/characters/${id}?`;
  //     var hash = Md5.hashStr(ts + Private_Key + Public_Key).toString();
  //     this.http.get(`MarvelApp/src/assets/marvel-master/data/matrixObject-${id}.json`)
  //       .pipe(map((res: Response) => res))
  //       .subscribe(data => {
  //         this.data = data;
  //         resolve(this.data);


  //       });
  //   });

  // }
  // getDescription(index: number): Observable<Marvels>   {
  //   if (this.data) return (this.data[index]); 


  //    }

  // searchData(name: string, type: SearchType): Observable<any> {
  //   return this.http.get(`https://gateway.marvel.com:443/v1/public/characters?ts=${this.ts}&apikey=${this.Public_Key}&hash=${this.hash}`)
  //     .pipe(map(results => {
  //       console.log('RAW', results);
  //       return results['Search'];
  //     }))

  // }

  // getDetail(id) {
  //   return this.http.get(`https://gateway.marvel.com:443/v1/public/characters/${id}?ts=${this.ts}&apikey=${this.Public_Key}&hash=${this.hash}`);
  // }


}
  // searchData( title:string,type:SearchType): Observable<any>{
  //   return this.http.get(`${this.Url}?s=${encodeURI(title)}&type=${type}&apikey=${this.Public_Key}`)
  // .pipe(
  //   map(results => {
  //     console.log('RAW: ',results);
  //     results['Search'];
  //     }  ));
  // }

