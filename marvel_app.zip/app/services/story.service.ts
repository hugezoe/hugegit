import { Injectable } from '@angular/core';
import { Md5 } from 'ts-md5/dist/md5';
import { map } from 'rxjs/operators';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Stories } from '../models/stories';
@Injectable({
  providedIn: 'root'
})
export class StoryService {
  data: any;

  constructor(public http: HttpClient) {
   
  }
  load() {
    if (this.data) {
      return Promise.resolve(this.data);
    }
    return new Promise(resolve => {
      this.http.get(`/assets/marvel-master/data/mcu-netflix.json`)
      .pipe(map ((res: Response) => res))
      .subscribe(data => {
        this.data = data;
        resolve(this.data);
      });
    });}
  
  
    getDetail(index: number): Promise<Stories> {
      return this.load()
      .then( data => { return data[index] as Stories;
      });
    }


}
