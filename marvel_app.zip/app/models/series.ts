
import { Thumbnail } from './thumbnail';



export class Series {
    id:number;
    name: string;
    wiki: string;
    series: string;
    phase: number;
    released: string;
    poster: string;
    // variants: [];
    // collections: [];
    // collectedIssues: [];
    // images: [];
}




