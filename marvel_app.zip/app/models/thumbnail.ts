export class Thumbnail {
    path: string;
    extension: string;
}