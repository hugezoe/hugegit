

export class Stories {
    id:number;
    name: string;
    wiki: string;
    series: string;
    season: number;
    released: string;
    poster: string;
}

