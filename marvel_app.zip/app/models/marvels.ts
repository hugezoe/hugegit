


export class Marvels {
    id: number;
    name: string;
    description: string;
    modified: string;
    thumbnail: string;
    resourceURI: string;
   

}


