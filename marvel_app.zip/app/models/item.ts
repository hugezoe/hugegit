export class ItemAbstract {
    resourceURI: string;
    name: string;
}

export class ItemStories extends ItemAbstract {
    type: string;
}
