import { Component, NgModule, OnInit, ViewChild } from '@angular/core';
import { from, Observable } from 'rxjs';
import { Path } from '../../../path';
// import { Gernerate_Response } from '../../models/gernerate';
import { MarvelService, SearchType, } from '../../services/marvel.service';
import { IonBackButton, IonicModule, IonSearchbar, NavController } from '@ionic/angular';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';



@Component({
  selector: 'app-marvel',
  templateUrl: './marvel.page.html',
  styleUrls: ['./marvel.page.scss'],
})
export class MarvelPage implements OnInit {

  // @ViewChild('search',{static:false}) search: IonSearchbar;

  public results: Observable<any>;
  public searchTerm: '';
  type: SearchType = SearchType.all;
  public obj: any;
  public heroes: any;
  public id;
  public name;

  constructor(public navCtrl: NavController, public heroService: MarvelService, private http: HttpClientModule) {
    this.getAllHeroes();

  }

  ngOnInit() {

  }


  getAllHeroes() {
    this.heroService.load()
      .then(data => {
        this.obj = data;
        this.heroes = this.obj.data.results;
      });
    

  }

  // searchChanged() {
  //   this.results = this.heroService.searchData(this.searchTerm,this.type);
  //   }

    
  }




  // this.getAllHeroes();
    // const val = ev.target.value;
    // if(val && val.trim()!='')
    // {
    //   this.heroes = this.heroes.filter((item) => {
    //     return (item.name.toLowerCase().indexOf(val.toLowerCase())>-1);
    //   })

  // results: Observable<any>;
  // searchTerm = '';
  // type: SearchType = SearchType.all;
  // constructor(private marvelService: MarvelService) { }


  // searchChanged() {
  //   this.results = this.marvelService.searchData(this.searchTerm,this.type);

    // this.results.subscribe(res => {
    //   console.log('My result:', this.results);
    // })
  // }


  // ionViewDidEnter(){
  //   setTimeout(() =>{
  //     this.search.setFocus();
  //   }
  //   )
  // }

  // ionChange(event){
  //   const val =event.target.value;
  //   this.searchedItem = this.getAllHeroes();
  //   if(val && val.trim() !=''){
  //     this.searchedItem = this.searchedItem.filter((item:any)=>{
  //       return (item.name.toLowerCase().indexOf(val.toLowerCase()) >-1);
  //     }
  //     )
  //   }