import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
const routes: Routes = [

  {
    path: '',
    redirectTo: 'marvel',
    pathMatch: 'full'
  },
  {
    path: 'marvel',
    loadChildren: () => import('./marvels/marvel/marvel.module').then( m => m.MarvelPageModule)
  },
  {
    path: 'marvel-series/:id',
    loadChildren: () => import('./series/marvel-series-detail/marvel-series-detail.module').then( m => m.MarvelSeriesDetailPageModule)
  },
  {
    path: 'marvel-story/:id',
    loadChildren: () => import('./stories/marvel-story-detail/marvel-story-detail.module').then( m => m.MarvelStoryDetailPageModule)
  },
  {
    path: 'marvel-story',
    loadChildren: () => import('./stories/marvel-story/marvel-story.module').then( m => m.MarvelStoryPageModule)
  },
  {
    path: 'marvel-series',
    loadChildren: () => import('./series/marvel-series/marvel-series.module').then( m => m.MarvelSeriesPageModule)
  },
 
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
